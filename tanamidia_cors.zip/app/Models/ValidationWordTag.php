<?php

namespace App\Models;

class ValidationWordTag
{
    const RULE_WORDTAG = [
        'word_id' => 'required',
        'name' => 'required',
    ];
}
